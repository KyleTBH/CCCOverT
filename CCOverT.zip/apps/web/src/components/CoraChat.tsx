import { useRef, useState } from 'react';
import type { AiReport } from '@ccovert/shared';
import { aiApi, getErrorMessage } from '../lib/api';
import { WarningList } from './ReferenceChart';

type Exchange = { question: string; answer: Pick<AiReport, 'body' | 'citations' | 'warnings'> };
export function CoraChat({ report }: { report: AiReport | null }): JSX.Element {
  const [question, setQuestion] = useState('');
  const [messages, setMessages] = useState<Exchange[]>([]);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const sending = useRef(false);
  const send = async (event: React.FormEvent): Promise<void> => {
    event.preventDefault();
    const text = question.trim();
    if (!report || !text || sending.current) return;
    sending.current = true; setPending(true); setError('');
    try {
      const { answer } = await aiApi.ask(report.id, text);
      setMessages((current) => [...current, { question: text, answer }]);
      setQuestion('');
    } catch (failure) { setError(getErrorMessage(failure)); }
    finally { sending.current = false; setPending(false); }
  };
  return <form className="report-question cora-chat" onSubmit={send}>
    <label htmlFor="cora-question"><span className="material-symbols-rounded" aria-hidden="true">auto_awesome</span>Ask Cora</label>
    <p className="form-hint" id="cora-help">{report ? 'Ask a question about this report. Answers appear here without changing your saved report. This conversation clears when you switch reports or refresh.' : 'Generate or open a report to ask Cora about it.'}</p>
    <div className="cora-conversation" role="log" aria-label="Questions and answers">
      {messages.map((message, index) => <div className="cora-exchange" key={index}>
        <div className="cora-user"><strong>You</strong><p>{message.question}</p></div>
        <div className="cora-answer"><strong>Cora</strong><p>{message.answer.body}</p>
          <WarningList warnings={message.answer.warnings} title="Answer limitations" />
          {message.answer.citations.length > 0 && <details><summary>Sources</summary><ul>{message.answer.citations.map((citation, i) => <li key={i}>{citation.filename ?? citation.predictionId ?? 'Source'}: {citation.excerpt}</li>)}</ul></details>}
        </div>
      </div>)}
    </div>
    <textarea id="cora-question" rows={3} maxLength={2000} value={question} onChange={(event) => setQuestion(event.target.value)} disabled={!report || pending} placeholder="Ask Cora about this report…" aria-describedby="cora-help cora-count" />
    <div className="report-question-footer"><span className="muted" id="cora-count">{question.length.toLocaleString()} / 2,000</span><button className="button button-primary" type="submit" disabled={!report || !question.trim() || pending}><span className="material-symbols-rounded" aria-hidden="true">send</span>{pending ? 'Asking Cora…' : 'Send question'}</button></div>
    {pending && <p role="status" className="form-hint">Cora is preparing an answer…</p>}
    {error && <p role="alert" className="cora-error">{error}</p>}
  </form>;
}
