import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { to: '/home', label: 'Dashboard', icon: 'dashboard', end: true },
  { to: '/predict', label: 'Predict', icon: 'query_stats' },
  { to: '/history', label: 'History', icon: 'history' },
  { to: '/ai', label: 'Reports', icon: 'auto_awesome' },
  { to: '/guide', label: 'Guide and FAQ', icon: 'help_outline' },
  { to: '/settings', label: 'Settings', icon: 'settings' }
];

const linkClass = ({ isActive }: { isActive: boolean }): string => (isActive ? 'nav-link active' : 'nav-link');

export function PublicHeader(): JSX.Element {
  const { user } = useAuth();
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link className="brand" to="/" aria-label="CCOverT home"><span className="brand-logo-frame" aria-hidden="true"><img className="brand-logo" src="/ccovert-logo.png" alt="" /></span><span>CCOverT</span></Link>
        <nav className="public-nav" aria-label="Public navigation">
          {user ? <Link className="button button-small" to="/home">Open app</Link> : <><Link to="/login">Log in</Link><Link className="button button-small" to="/signup">Create account</Link></>}
        </nav>
      </div>
    </header>
  );
}

export function AppShell({ children }: { children: React.ReactNode }): JSX.Element {
  const { user, updatePreferences, logout } = useAuth();
  const [announcement, setAnnouncement] = useState('');
  const [sidebarExpanded, setSidebarExpanded] = useState(() => window.innerWidth >= 1024);
  const moreRef = useRef<HTMLDetailsElement>(null);
  const location = useLocation();
  useEffect(() => { if (moreRef.current) moreRef.current.open = false; }, [location.pathname]);
  useEffect(() => {
    const closeOutside = (event: PointerEvent): void => {
      if (moreRef.current && !moreRef.current.contains(event.target as Node)) moreRef.current.open = false;
    };
    const closeOnResize = (): void => { if (moreRef.current) moreRef.current.open = false; };
    document.addEventListener('pointerdown', closeOutside);
    window.addEventListener('resize', closeOnResize);
    return () => { document.removeEventListener('pointerdown', closeOutside); window.removeEventListener('resize', closeOnResize); };
  }, []);
  useEffect(() => {
    const refresh = (): void => {
      fetch('/api/v1/developer/config', { credentials: 'include' })
        .then((response) => response.ok ? response.json() : null)
        .then((body: { config?: { announcement?: string } } | null) => setAnnouncement(body?.config?.announcement ?? ''))
        .catch(() => undefined);
    };
    refresh();
    const interval = window.setInterval(refresh, 15000);
    return () => window.clearInterval(interval);
  }, []);
  const toggleTheme = (): void => {
    if (user) void updatePreferences({ ...user.preferences, theme: user.preferences.theme === 'dark' ? 'light' : 'dark' });
  };
  return (
    <div className={`app-frame responsive-navigation${sidebarExpanded ? ' navigation-expanded' : ''}`}>
      <a className="skip-link" href="#workspace-main">Skip to content</a>
      <header className="site-header app-header">
        <div className="header-inner">
          <Link className="brand" to="/home"><span className="brand-logo-frame" aria-hidden="true"><img className="brand-logo" src="/ccovert-logo.png" alt="" /></span><span>CCOverT</span></Link>
          <div className="header-actions">
            <button className="theme-toggle" type="button" onClick={toggleTheme} aria-label={`Switch to ${user?.preferences.theme === 'dark' ? 'light' : 'dark'} mode`} title="Toggle theme">
              <span className="material-symbols-rounded" aria-hidden="true">{user?.preferences.theme === 'dark' ? 'light_mode' : 'dark_mode'}</span>
            </button>
          </div>
        </div>
      </header>
      {announcement && <div className="system-announcement" role="status">{announcement}</div>}
      <aside className={`app-sidebar${sidebarExpanded ? ' app-sidebar-expanded' : ''}`} aria-label="Workspace sidebar">
        <Link className="sidebar-brand" to="/home" aria-label="CCOverT home"><span className="brand-logo-frame" aria-hidden="true"><img className="brand-logo" src="/ccovert-logo.png" alt="" /></span><span>CCOverT</span></Link>
        <button className="sidebar-toggle" type="button" aria-label={sidebarExpanded ? 'Collapse sidebar' : 'Expand sidebar'} aria-expanded={sidebarExpanded} onClick={() => setSidebarExpanded((expanded) => !expanded)} title={sidebarExpanded ? 'Collapse sidebar' : 'Expand sidebar'}>
          <span className="material-symbols-rounded" aria-hidden="true">{sidebarExpanded ? 'left_panel_close' : 'left_panel_open'}</span>
        </button>
        <nav className="nav-island" aria-label="Primary navigation">
          {navItems.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={linkClass} aria-label={item.label} title={item.label}>
              <span className="material-symbols-rounded nav-icon" aria-hidden="true">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
            </NavLink>
          ))}
          <button className="sidebar-logout" type="button" aria-label="Log out" title="Log out" onClick={() => void logout()}>
            <span className="material-symbols-rounded" aria-hidden="true">logout</span>
            <span className="sidebar-label">Log out</span>
          </button>
        </nav>
      </aside>
      <nav className="mobile-navigation" aria-label="Mobile navigation">
        {navItems.slice(0, 4).map((item) => <NavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => `mobile-nav-item${isActive ? ' active' : ''}`}>
          <span className="material-symbols-rounded" aria-hidden="true">{item.icon}</span><span>{item.label === 'Dashboard' ? 'Home' : item.label}</span>
        </NavLink>)}
        <details ref={moreRef} className="mobile-more" onKeyDown={(event) => { if (event.key === 'Escape') { event.currentTarget.open = false; event.currentTarget.querySelector('summary')?.focus(); } }}>
          <summary className={`mobile-nav-item${['/guide', '/settings'].includes(location.pathname) ? ' active' : ''}`} aria-label="More navigation options"><span className="material-symbols-rounded" aria-hidden="true">more_horiz</span><span>More</span></summary>
          <div className="mobile-more-panel">
            <p>More options</p>
            {navItems.slice(4).map((item) => <NavLink key={item.to} to={item.to} onClick={() => { if (moreRef.current) moreRef.current.open = false; }}><span className="material-symbols-rounded" aria-hidden="true">{item.icon}</span>{item.label}</NavLink>)}
            <button type="button" onClick={() => { if (moreRef.current) moreRef.current.open = false; void logout(); }}><span className="material-symbols-rounded" aria-hidden="true">logout</span>Log out</button>
          </div>
        </details>
      </nav>
      {!user?.emailVerified && (user?.role === 'client' || user?.role === 'user') && (
        <div className="verification-banner" role="status">
          Verify your email to unlock saved predictions, data import, and reports. <Link to="/settings">Open settings</Link>
        </div>
      )}
      <main id="workspace-main" className="app-main" tabIndex={-1}>{children}</main>
    </div>
  );
}

export function PageHeader({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }): JSX.Element {
  return (
    <div className="page-header">
      <div>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h1>{title}</h1>{description && <p className="lede">{description}</p>}</div>
      {action}
    </div>
  );
}
