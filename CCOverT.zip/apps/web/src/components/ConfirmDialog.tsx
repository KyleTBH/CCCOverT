import { useEffect, useId, useRef, useState } from 'react';

export function ConfirmDialog({ open, title, children, confirmLabel = 'Confirm', onCancel, onConfirm }: { open: boolean; title: string; children: React.ReactNode; confirmLabel?: string; onCancel: () => void; onConfirm: () => void }): JSX.Element | null {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const dialog = dialogRef.current;
    if (open && dialog && !dialog.open) dialog.showModal();
    if (!open && dialog?.open) dialog.close();
    return () => { if (dialog?.open) dialog.close(); };
  }, [open]);
  return <dialog ref={dialogRef} className="dialog native-confirm-dialog" aria-labelledby={titleId} onCancel={(event) => { event.preventDefault(); onCancel(); }}>
    <h2 id={titleId}>{title}</h2>
    <div className="dialog-body">{children}</div>
    <div className="dialog-actions"><button autoFocus className="button button-secondary" type="button" onClick={onCancel}>Cancel</button><button className="button button-danger" type="button" onClick={onConfirm}>{confirmLabel}</button></div>
  </dialog>;
}

export function useDisclosure(): { open: boolean; openDialog: () => void; closeDialog: () => void } {
  const [open, setOpen] = useState(false);
  return { open, openDialog: () => setOpen(true), closeDialog: () => setOpen(false) };
}
