import { CoraChat } from '../components/CoraChat';
import { useCallback, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import type { AiReport, PredictionRecord } from '@ccovert/shared';
import { aiApi, getErrorMessage, predictionsApi } from '../lib/api';
import { AppShell, PageHeader } from '../components/AppShell';
import { EmptyState, LoadingState, Notice } from '../components/States';
import { ConditionBadge, WarningList } from '../components/ReferenceChart';

export function AiPage(): JSX.Element {
  const [params] = useSearchParams();
  const [predictions, setPredictions] = useState<PredictionRecord[]>([]);
  const [reports, setReports] = useState<AiReport[]>([]);
  const [selectedPredictions, setSelectedPredictions] = useState<string[]>(params.get('prediction') ? [params.get('prediction') as string] : []);
  const [active, setActive] = useState<AiReport | null>(null);
  const [reportExpanded, setReportExpanded] = useState(true);
  const [error, setError] = useState('');
  const [pending, setPending] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState('');
  const [deleteMessage, setDeleteMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    Promise.all([predictionsApi.list(200), aiApi.reports()])
      .then(([runs, library]) => { setPredictions(runs.predictions); setReports(library.reports); })
      .catch((loadError: unknown) => setError(getErrorMessage(loadError)))
      .finally(() => setLoading(false));
  }, []);

  useEffect(load, [load]);

  const toggle = (values: string[], value: string, setter: (next: string[]) => void): void => {
    setter(values.includes(value) ? values.filter((candidate) => candidate !== value) : [...values, value]);
  };

  const deleteReport = async (report: AiReport): Promise<void> => {
    if (deleting || !window.confirm(`Delete "${report.title}"? This cannot be undone. Your prediction runs will be kept.`)) return;
    setDeleting(report.id);
    setDeleteError('');
    setDeleteMessage('');
    try {
      await aiApi.deleteReport(report.id);
      setReports((current) => current.filter((saved) => saved.id !== report.id));
      setActive((current) => current?.id === report.id ? null : current);
      setDeleteMessage('Report deleted. Your prediction runs have been kept.');
    } catch (deleteFailure) {
      setDeleteError(getErrorMessage(deleteFailure));
    } finally {
      setDeleting(null);
    }
  };

  const reportLocation = (report: AiReport): string => {
    const runs = report.referencedPredictionIds.map((id) => predictions.find((run) => run.predictionId === id));
    const places = [...new Set(runs.flatMap((run) => run?.studyArea.label ? [run.studyArea.label] : []))];
    if (!places.length) return 'Location unavailable';
    return places.join(' · ') + (runs.some((run) => !run) ? ' · Some locations unavailable' : '');
  };

  const generate = async (event: React.FormEvent): Promise<void> => {
    event.preventDefault();
    setError('');
    setPending(true);
    try {
      const response = await aiApi.createReport({
        predictionIds: selectedPredictions,
      });
      setActive(response.report);
      setReportExpanded(true);
      setReports((current) => [response.report, ...current.filter((saved) =>
        !saved.referencedPredictionIds.some((id) => response.report.referencedPredictionIds.includes(id))
      )]);
    } catch (generateError) {
      setError(getErrorMessage(generateError));
    } finally {
      setPending(false);
    }
  };

  return (
    <AppShell>
      <div className="page-container ai-page reports-workspace">
        <PageHeader eyebrow="Research workspace" title="Reports" description="Turn your coral-cover predictions into clear, traceable research reports." action={<Link className="button button-secondary" to="/predict"><span className="material-symbols-rounded" aria-hidden="true">add</span>New prediction</Link>} />
        <div className="reports-overview" aria-label="Report overview">
          <div><span className="material-symbols-rounded" aria-hidden="true">query_stats</span><div><strong>{loading ? '—' : predictions.length}</strong><span>Available predictions</span></div></div>
          <div><span className="material-symbols-rounded" aria-hidden="true">task_alt</span><div><strong>{selectedPredictions.length}</strong><span>Selected for report</span></div></div>
          <div><span className="material-symbols-rounded" aria-hidden="true">description</span><div><strong>{loading ? '—' : reports.length}</strong><span>Saved reports</span></div></div>
        </div>
        {error && <Notice tone="danger" title="Could not complete the request">{error}<button className="button button-small button-secondary" type="button" onClick={load}>Reload reports</button></Notice>}
        {loading && <LoadingState label="Loading predictions and reports" />}

        {deleteError && <Notice tone="danger" title="Could not delete report">{deleteError}</Notice>}
        {deleteMessage && <p role="status" className="muted">{deleteMessage}</p>}
        <div className="ai-layout">
          <form className="form-panel ai-builder" onSubmit={generate} noValidate>
            <fieldset disabled={pending || loading || Boolean(error)}>
              <div className="ai-step-heading"><span className="ai-step-number">01</span><div><p className="eyebrow">Step one · Evidence</p><h2>Choose predictions</h2><p className="muted">Select runs, then generate your report.</p></div></div>
              <div className="ai-source-grid">
                <div className="prediction-history-picker">
                  <div className="panel-heading"><h3>Saved predictions</h3><span className="condition-badge condition-good" aria-live="polite">{selectedPredictions.length} selected</span></div>
                  {!loading && !error && predictions.length === 0 && <EmptyState title="No saved predictions">
                    <p>Run a prediction to get started.</p>
                    <Link className="button button-primary" to="/predict">Run a prediction</Link>
                  </EmptyState>}
                  <div className="ai-prediction-list">
                    {predictions.map((prediction) => (
                      <label className="ai-prediction-card" key={prediction.predictionId} htmlFor={`prediction-${prediction.predictionId}`}>
                        <input
                          id={`prediction-${prediction.predictionId}`}
                          type="checkbox"
                          checked={selectedPredictions.includes(prediction.predictionId)}
                          onChange={() => toggle(selectedPredictions, prediction.predictionId, setSelectedPredictions)}
                        />
                        <span className="ai-prediction-card-body">
                          <span className="card-kicker">
                            <span className="prediction-measure">{prediction.targetMeasure}</span>
                            {prediction.isDemo
                              ? <ConditionBadge label="DEMO" status="danger" />
                              : prediction.isScenario
                                ? <ConditionBadge label="SCENARIO - exploratory" status="danger" />
                                : prediction.status === 'unavailable'
                                  ? <ConditionBadge label="Not completed" status="unavailable" />
                                  : <ConditionBadge label="Model projection" status="good" />}
                          </span>
                          <span className="prediction-value-label">Projected coral cover</span>
                          <strong className="ai-prediction-value">{prediction.status === 'unavailable' ? 'Not completed' : `${prediction.finalCoverPercent.toFixed(2)}%`}</strong>
                          <span className="prediction-period">Period: {prediction.baselineYear}–{prediction.forecastEndYear ?? prediction.baselineYear + prediction.horizonYears}</span>
                          <span className="muted">Starting cover: {prediction.initialCoverPercent.toFixed(2)}%</span>
                          <span className="muted">Created {new Date(prediction.createdAt).toLocaleDateString()}</span>
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              <div className="report-generate-actions">
              {selectedPredictions.length === 0 && <p className="form-hint">Choose at least one prediction.</p>}
              <button className="button button-primary button-wide" type="submit" disabled={pending || selectedPredictions.length === 0}>
                {pending ? 'Generating report…' : 'Generate report'}
              </button>
              </div>
            </fieldset>
          </form>

          <section id="report-preview" aria-label="Report preview" aria-busy={pending} className={`report-panel ${active && !reportExpanded ? 'report-panel-collapsed' : ''}`}>
            <div className="ai-step-heading"><span className="ai-step-number">02</span><div><p className="eyebrow">Step two · Interpretation</p><h2>{active ? active.title : 'Report preview'}</h2><p className="muted">Generate a report to see the interpretation, caveats, and citations.</p></div>{active && <button className="button button-small button-secondary" type="button" onClick={() => setReportExpanded((expanded) => !expanded)}>{reportExpanded ? 'Collapse report' : 'View full report'}</button>}</div>
            {active && (
              <>
                <p className="muted">
                  {active.generatedBy === 'ai-provider' ? 'AI-assisted report' : 'Calculation-based summary'}
                  {active.model ? ` (${active.model})` : ''} on {new Date(active.createdAt).toLocaleString()}
                </p>
                {reportExpanded && <WarningList warnings={active.warnings} title="Report warnings" />}
                {reportExpanded && <div className="report-content">
                  {active.body.split('\n').map((line, index) => (
                    line.startsWith('# ') || line.startsWith('## ')
                      ? <h3 key={index}>{line.replace(/^#+ /, '')}</h3>
                      : line.startsWith('- ')
                        ? <p className="muted" key={index}>&bull; {line.slice(2)}</p>
                        : <p key={index}>{line}</p>
                  ))}
                </div>}
                {reportExpanded && active.citations.length > 0 && (
                  <>
                    <h3>Citations</h3>
                    <ol className="reference-list">
                      {active.citations.map((citation, index) => (
                        <li key={`${citation.uploadId ?? citation.predictionId}-${index}`}>
                          {citation.filename ?? (citation.predictionId ? `Prediction ${citation.predictionId.slice(0, 8)}` : 'Source')}
                          {citation.page ? `, page ${citation.page}` : ''}: {citation.excerpt}
                        </li>
                      ))}
                    </ol>
                  </>
                )}
              </>
            )}
            {!active && <div className="ai-report-empty"><span className="material-symbols-rounded" aria-hidden="true">auto_awesome</span><strong>Your next research report starts here</strong><p>Select saved predictions and choose Generate report. Review the interpretation, limitations, and sources in one place.</p><div className="report-outline"><span>01 · Prediction summary</span><span>02 · Interpretation &amp; limitations</span><span>03 · Sources &amp; citations</span></div><small>Generated reports are saved to your library automatically.</small></div>}
            <CoraChat key={active?.id ?? "no-report"} report={active} />
          </section>
        <section className="panel ai-library">
          <div className="ai-step-heading"><span className="ai-step-number">03</span><div><p className="eyebrow">Your library</p><h2>Report library</h2><p className="muted">Reopen a previous report to review its evidence and findings.</p></div><span className="condition-badge condition-good">{reports.length} {reports.length === 1 ? 'report' : 'reports'}</span></div>
          <label className="report-search"><span className="material-symbols-rounded" aria-hidden="true">search</span><span className="sr-only">Search saved reports</span><input type="search" placeholder="Search reports by title…" value={search} onChange={(event) => setSearch(event.target.value)} /></label>
          {!loading && !error && reports.length === 0 ? <div className="reports-library-empty"><span className="material-symbols-rounded" aria-hidden="true">folder_open</span><div><h3>A home for your research</h3><p className="muted">Your saved reports will appear here. Create your first report above.</p></div></div> : (
            <div className="ai-library-list">
              {reports.filter((report) => report.title.toLowerCase().includes(search.toLowerCase())).map((report) => (
                <article className={`ai-library-card${active?.id === report.id ? ' report-is-active' : ''}`} key={report.id}>
                  <div className="ai-library-card-meta">
                    <ConditionBadge label={report.generatedBy === 'ai-provider' ? 'AI report' : 'Deterministic summary'} status={report.generatedBy === 'ai-provider' ? 'good' : 'warning'} />
                    <time className="report-card-date" dateTime={report.createdAt}>Created {new Date(report.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</time>
                  </div>
                  <div className="ai-library-card-body">
                    <h3>{report.title}</h3>
                    <p className="report-card-location"><span className="material-symbols-rounded" aria-hidden="true">location_on</span>{reportLocation(report)}</p>
                    <p className="muted">{report.referencedPredictionIds.length} prediction(s) · {report.referencedUploadIds.length} document(s) · {report.citations.length} citation(s)</p>
                    <div className="report-card-actions">
                      <button className="button button-primary" type="button" onClick={() => { setActive(report); setReportExpanded(true); document.getElementById('report-preview')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}><span className="material-symbols-rounded" aria-hidden="true">description</span>Open report</button>
                      <details className="report-card-options" onKeyDown={(event) => { if (event.key === 'Escape') { event.currentTarget.open = false; event.currentTarget.querySelector('summary')?.focus(); } }}>
                        <summary aria-label={`Options for ${report.title}`} title="Report options"><span className="material-symbols-rounded" aria-hidden="true">more_horiz</span></summary>
                        <div className="report-options-panel">
                          <button className="button button-small button-danger" type="button" disabled={deleting !== null || pending} aria-label={`Delete report: ${report.title}`} onClick={(event) => { const menu = event.currentTarget.closest('details'); if (menu) menu.open = false; void deleteReport(report); }}><span className="material-symbols-rounded" aria-hidden="true">delete</span>{deleting === report.id ? 'Deleting…' : 'Delete report'}</button>
                        </div>
                      </details>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
          {!loading && reports.length > 0 && !reports.some((report) => report.title.toLowerCase().includes(search.toLowerCase())) && <p className="muted" role="status">No reports match “{search}”. Try another title.</p>}
        </section>
        </div>
      </div>
    </AppShell>
  );
}
